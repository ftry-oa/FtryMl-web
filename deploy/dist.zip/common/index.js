
export const common = '1.1'